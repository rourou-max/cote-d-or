const express = require("express");
require("dotenv").config();
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 5000;
const dbConnect = require("./config/db");

// Connexion à MongoDB
dbConnect.connect();

app.use(cors({
    origin: "*",
    credentials: true // Si vous utilisez des cookies
}));

// Middleware pour parser les requêtes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir les fichiers statiques
app.use(express.static('views'));

// Routes
const UserRoutes = require("./routes/User");
const CommandeRoutes = require("./routes/Commande");
const FilRoutes = require("./routes/Fil");
const AnalyseRoutes = require("./routes/Analyse");
const analysefinanciereRoutes = require("./routes/analysefinanciere");

app.use("/user", UserRoutes);
app.use("/commande", CommandeRoutes);
app.use("/fil", FilRoutes);
app.use("/analyse", AnalyseRoutes);
app.use("/analysefinanciere",AnalyseRoutes);


// Route racine
app.get('/', (req, res) => {
    res.redirect('/login.html');
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});