const AnalyseModel = require('../models/Analyse')

exports.addAnalyse = async (req, res) => {
    try {
        const {
            name_machine,
            heure_debut,
            heure_fin,
            produit_initial,
            fils_produit,
            dechet,
            seuils,
            consommation_energie,
            rendement,
            consommation_specifique,
            etat
        } = req.body;

        // Validation de l'état
        const etatsValides = ['normale', 'panne', 'maintenance', 'changement operateur'];
        if (etat && !etatsValides.includes(etat)) {
            return res.status(400).json({
                success: false,
                message: "État invalide. Les valeurs autorisées sont : normale, panne, maintenance, changement operateur"
            });
        }

        // Créer une nouvelle analyse
        const nouvelleAnalyse = new AnalyseModel({
            name_machine,
            heure_debut,
            heure_fin,
            produit_initial,
            fils_produit,
            dechet,
            seuils,
            consommation_energie,
            rendement,
            consommation_specifique,
            etat: etat || 'normale' // Par défaut à "normale" si non spécifié
        });

        // Sauvegarder l'analyse
        await nouvelleAnalyse.save();

        return res.status(201).json({
            success: true,
            message: 'machine ajoutée avec succès',
            analyse: nouvelleAnalyse
        });
    } catch (error) {
        console.error('Erreur lors de l\'ajout de l\'machine:', error);
        return res.status(500).json({
            success: false,
            message: 'Erreur serveur lors de l\'ajout de l\'machine',
            error: error.message
        });
    }
};

exports.getAllAnalyses = async (req, res) => {
    try {
        // Récupérer toutes les analyses
        const analyses = await AnalyseModel.find();

        // Vérifier si des analyses existent
        if (analyses.length === 0) {
            return res.status(200).json({
                success: true,
                message: 'Aucune machine trouvée',
                analyses: []
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Machine récupérées avec succès',
            analyses
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des machines:', error);
        return res.status(500).json({
            success: false,
            message: 'Erreur serveur lors de la récupération des machine',
            error: error.message
        });
    }
};