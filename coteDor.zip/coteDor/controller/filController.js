const UserModel = require('../models/User');
const CommandeModel = require('../models/Commande');
const FilModel = require('../models/Fil');

exports.addFil = async(req,res)=>{
    try {
        const { consommateur, reference, type_fil, stock_disponible, prix_total } = req.body;

        if (!consommateur) {
            return res.status(400).json({
                message: "L'ID de l'utilisateur est requis"
            });
        }

        const user = await UserModel.findById(consommateur);
        if (!user || !user.isActive) {
            return res.status(404).json({
                message: "Utilisateur non trouvé ou inactif"
            });
        }

        const commande = await CommandeModel.findById(reference);
        if (!commande) {
            return res.status(404).json({
                message: "Commande non trouvé"
            });
        }

        const newFil = new FilModel({
            consommateur: user._id,
            reference: commande._id,
            type_fil,
            stock_disponible,
            prix_total
        });

        await newFil.save();

        return res.status(201).json({
            message: "Fil créée avec succès",
            order: newFil
        });
    } catch (error) {
        return res.status(500).json({
            message: "Erreur serveur lors du traitement de la Fil",
            error: error.message
        });
    }
};

exports.UpdateFil = async (req, res) => {
    try {
        const { id } = req.params;
        const { reference, type_fil, stock_disponible, consommateur, prix_total } = req.body;

        const fil = await FilModel.findById(id);
        if (!fil) {
            return res.status(404).json({ message: 'Fil non trouvé' });
        }

        if (reference) {
            const commande = await CommandeModel.findById(reference);
            if (!commande) {
                return res.status(404).json({ message: 'Commande non trouvée' });
            }
        }

        if (consommateur) {
            const user = await UserModel.findById(consommateur);
            if (!user) {
                return res.status(404).json({ message: 'Utilisateur non trouvé' });
            }
        }

        fil.reference = reference || fil.reference;
        fil.type_fil = type_fil || fil.type_fil;
        fil.stock_disponible = stock_disponible || fil.stock_disponible;
        fil.consommateur = consommateur || fil.consommateur;
        fil.prix_total = prix_total || fil.prix_total;

        await fil.save();

        return res.status(200).json({
            message: 'Fil mis à jour avec succès',
            fil,
        });
    } catch (error) {
        console.error('Erreur lors de la mise à jour du fil:', error);
        return res.status(500).json({
            message: 'Erreur serveur',
            error: error.message,
        });
    }
};

exports.GetAllFil = async (req, res) => {
    try {

        const fils = await FilModel.find()
            .populate('reference', 'ref')
            .populate('consommateur', 'nom prenom email');

        return res.status(200).json(fils);
    } catch (error) {
        console.error('Erreur lors de la récupération des fils:', error);
        return res.status(500).json({
            message: 'Erreur serveur',
            error: error.message,
        });
    }
};

exports.GetFilByUser = async (req, res) => {
    try {
        const userId = req.params.userId || req.user.id;

        const currentUser = await UserModel.findById(req.user.id);
        if (!currentUser) {
            return res.status(404).json({ message: 'Utilisateur connecté non trouvé' });
        }

        const targetUser = await UserModel.findById(userId);
        if (!targetUser) {
            return res.status(404).json({ message: 'Utilisateur non trouvé' });
        }

        if (currentUser.role !== 'admin' && userId !== req.user.id) {
            return res.status(403).json({ message: 'Accès refusé : vous ne pouvez voir que vos propres fils' });
        }

        const fils = await FilModel.find({ consommateur: userId })
            .populate('reference', 'ref')
            .populate('consommateur', 'nom prenom email');

        return res.status(200).json(fils);
    } catch (error) {
        console.error('Erreur lors de la récupération des fils par utilisateur:', error);
        return res.status(500).json({
            message: 'Erreur serveur',
            error: error.message,
        });
    }
};

exports.GetFilById = async (req, res) => {
    try {
        const { id } = req.params;

        const fil = await FilModel.findById(id)
            .populate('reference', 'ref')
            .populate('consommateur', 'nom prenom email');
        if (!fil) {
            return res.status(404).json({ message: 'Fil non trouvé' });
        }
        return res.status(200).json(fil);
    } catch (error) {
        console.error('Erreur lors de la récupération du fil:', error);
        return res.status(500).json({
            message: 'Erreur serveur',
            error: error.message,
        });
    }
};