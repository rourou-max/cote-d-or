const UserModel = require('../models/User');
const CommandeModel = require('../models/Commande');

exports.AddCommande = async (req, res) => {
    try {
        const { userId, ref, quantite, avancement } = req.body;

        if (!userId) {
            return res.status(400).json({
                message: "L'ID de l'utilisateur est requis"
            });
        }

        const user = await UserModel.findById(userId);
        if (!user || !user.isActive) {
            return res.status(404).json({
                message: "Utilisateur non trouvé ou inactif"
            });
        }

        if (!quantite || quantite <= 0) {
            return res.status(400).json({
                message: "La quantité doit être supérieure à 0"
            });
        }

        const newOrder = new CommandeModel({
            userId: user._id,
            ref: ref || '',
            quantite,
            avancement: avancement || '',
            date_reception: new Date(),
            statut: "en attente"
        });

        await newOrder.save();

        return res.status(201).json({
            message: "Commande créée avec succès",
            order: newOrder
        });
    } catch (error) {
        console.error("Erreur lors de la création de la commande:", error);
        return res.status(500).json({
            message: "Erreur serveur lors du traitement de la commande",
            error: error.message
        });
    }
};

// Nouvelle méthode pour récupérer les commandes d'un utilisateur spécifique
exports.getCommandesByUser = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await UserModel.findById(userId);
        if (!user) {
            return res.status(404).json({ message: "Utilisateur non trouvé" });
        }
        const commandes = await CommandeModel.find({ userId });
        res.json(commandes);
    } catch (error) {
        res.status(500).json({
            message: "Erreur lors de la récupération des commandes",
            error: error.message
        });
    }
};

// Nouvelle méthode pour récupérer les commandes de l'utilisateur connecté
exports.getCommandesByCurrentUser = async (req, res) => {
    try {
        const userId = req.user.id; // Via authMiddleware
        const commandes = await CommandeModel.find({ userId });
        res.json(commandes);
    } catch (error) {
        res.status(500).json({
            message: "Erreur lors de la récupération des commandes",
            error: error.message
        });
    }
};

exports.getAllCommandes = async (req, res) => {
    try {
        const commandes = await CommandeModel.find();
        res.json(commandes);
    } catch (error) {
        res.status(500).json({
            message: "Erreur lors de la récupération des commandes",
            error: error.message
        });
    }
};
exports.updateCommandeStatus = async (req, res) => {
    try {
        const { id } = req.params; // ID de la commande
        const { statut } = req.body; // Nouveau statut

        // Vérifier si le statut est valide
        const statutsValides = ['en attente', 'en cours', 'terminée'];
        if (!statutsValides.includes(statut)) {
            return res.status(400).json({
                success: false,
                message: 'Statut invalide. Les valeurs autorisées sont : en attente, en cours, terminée',
            });
        }

        // Vérifier si la commande existe
        const commande = await CommandeModel.findById(id);
        if (!commande) {
            return res.status(404).json({
                success: false,
                message: 'Commande non trouvée',
            });
        }

        // Mettre à jour le statut
        commande.statut = statut;
        await commande.save();

        return res.status(200).json({
            success: true,
            message: 'Statut de la commande mis à jour avec succès',
            commande,
        });
    } catch (error) {
        console.error('Erreur lors de la mise à jour du statut de la commande:', error);
        return res.status(500).json({
            success: false,
            message: 'Erreur serveur lors de la mise à jour du statut',
            error: error.message,
        });
    }
};