const UserModel = require('../models/User');
const CommandeModel = require('../models/Commande'); // Ajout pour récupérer les commandes
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

exports.addUser = async (req, res) => {
    const {
        email,
        password,
        nom,
        prenom,
        telephone,
        role // Ajout du rôle
    } = req.body;

    if (!password || !nom || !prenom || !telephone || !email) {
        return res.status(400).json({ message: "Tous les champs marqués d'un * sont obligatoires." });
    }

    try {
        // Vérifier si l'email existe déjà
        const existingUser = await UserModel.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Cet email est déjà utilisé." });
        }

        // Créer un nouvel utilisateur
        const passwordHash = await bcrypt.hash(password, 10);

        const userData = {
            email,
            password: passwordHash,
            nom,
            prenom,
            telephone,
            role: role || "client" // Par défaut client si non spécifié
        };
        const user = new UserModel(userData);
        await user.save();
        res.status(201).json({ message: "Utilisateur enregistré avec succès" });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getAllUser = async (req, res) => {
    try {
        const allUser = await UserModel.find();
        return res.status(200).json(allUser);
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.updateUser = async (req, res) => {
    try {
        const {
            email,
            password,
            nom,
            prenom,
            telephone,
            role // Ajout du rôle
        } = req.body;

        // Trouver l'utilisateur à mettre à jour
        const user = await UserModel.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: "Utilisateur introuvable" });
        }

        // Mettre à jour les champs de l'utilisateur
        user.email = email || user.email;
        user.nom = nom || user.nom;
        user.prenom = prenom || user.prenom;
        user.telephone = telephone || user.telephone;
        user.role = role || user.role;
        if (password) {
            user.password = await bcrypt.hash(password, 10);
        }

        await user.save();

        res.json(user);
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getByIdUser = async (req, res) => {
    try {
        const { userId } = req.params;
        const userById = await UserModel.findById(userId);
        if (!userById)
            return res.status(400).json({ msg: "Utilisateur n'existe pas" });
        res.json(userById);
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Rechercher l'utilisateur
        const user = await UserModel.findOne({ email });
        if (!user) {
            return res.status(401).json({ msg: "Email ou mot de passe incorrect" });
        }

        // Vérifier le mot de passe
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ msg: "Email ou mot de passe incorrect" });
        }

        // Vérifier le statut
        if (!user.isActive) {
            return res.status(403).json({ msg: "Votre compte est bloqué" });
        }

        // Générer un access token
        const accesstoken = createAccessToken({ id: user._id });

        // Retourner les informations et la redirection selon le rôle
        res.json({
            user: {
                id: user._id,
                email: user.email,
                nom: user.nom,
                prenom: user.prenom,
                role: user.role
            },
            accesstoken,
            redirect: user.role === 'admin' ? '/user/list' : '/commande/list'
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.refreshToken = async (req, res) => {
    try {
        let rf_token = req.cookies.refreshtoken;
        if (!rf_token)
            return res.status(400).json({ msg: "Veuillez vous connecter ou vous inscrire" });
        jwt.verify(rf_token, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
            if (err)
                return res.status(400).json({ msg: "Veuillez vous connecter ou vous inscrire" });
            let accesstoken = createAccessToken({ id: user.id });
            res.json({ accesstoken });
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.logout = async (req, res) => {
    try {
        // Effacer le cookie refreshtoken, si utilisé
        res.clearCookie("refreshtoken", { path: "/refresh_token" });
        // Rediriger vers login.html
        res.redirect('/login.html');
    } catch (error) {
        console.error('Erreur lors de la déconnexion:', error);
        res.status(500).redirect('/login.html'); // Redirection en cas d'erreur
    }
};
exports.getUserByToken = async (req, res) => {
    try {
        const userId = req.user.id;
        let user = await UserModel.findById(userId);
        if (!user) {
            return res.status(404).json({ msg: 'Utilisateur non trouvé' });
        }
        res.json({ user });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

const createAccessToken = (user) => {
    return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, {
        expiresIn: "1d",
    });
};