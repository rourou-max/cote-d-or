const analysefinanciere = require('../models/analysefinanciere');

const enregistreranalysefinanciere = async (req, res) => {
    try {
        const { annee, mois, ventes, achats, marge, rentabilite } = req.body;

        // Validation des données
        if (!annee || !mois || !ventes || !achats || !marge || !rentabilite) {
            return res.status(400).json({ error: 'Tous les champs sont requis' });
        }

        // Créer un document pour chaque mois
        const analysefinanciereData = mois.map((m, index) => ({
            annee: parseInt(annee),
            mois: m,
            ventes: parseFloat(ventes[index] || 0),
            achats: parseFloat(achats[index] || 0),
            marge: parseFloat(marge[index] || 0),
            rentabilite: parseFloat(rentabilite[index] || 0)
        }));

        // Enregistrer dans MongoDB
        await analysefinanciere.insertMany(analysefinanciereData);

        res.status(201).json({ message: 'Données enregistrées avec succès' });
    } catch (error) {
        console.error('Erreur lors de l\'enregistrement :', error);
        res.status(500).json({ error: 'Erreur serveur lors de l\'enregistrement' });
    }
};

const listeranalysefinanciere = async (req, res) => {
    try {
        // Récupérer toutes les analysefinanciere, triées par année et mois
        const analysefinanciere = await analysefinanciere.find().sort({ annee: 1, mois: 1 });
        res.status(200).json(analyses);
    } catch (error) {
        console.error('Erreur lors de la récupération des analyse financiere :', error);
        res.status(500).json({ error: 'Erreur serveur lors de la récupération des analyse financiere' });
    }
};

module.exports = { enregistreranalysefinanciere, listeranalysefinanciere };
