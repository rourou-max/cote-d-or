const mongoose = require("mongoose");

const CommandeSchema = new mongoose.Schema({
	userId: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "User",
	},
	ref: { type: String, required: false },
	quantite: { type: Number, required: false},
	date_reception: { 
		type: Date, 
		default: Date.now
	},
	avancement: { type: String, required: false },
	statut: {
        type: String,
        enum: ["en attente", "en cours", "terminée"],
        default: "en attente",
    },
});

const Commande = mongoose.model("Commande", CommandeSchema);
module.exports = Commande;
