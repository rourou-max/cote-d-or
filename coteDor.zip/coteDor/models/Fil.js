const mongoose = require("mongoose");

const FilSchema = new mongoose.Schema({
	reference: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "Commande",
	},
	type_fil: { type: String, required: false },
	stock_disponible: { type: String, required: false},
	consommateur: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "User",
	},
	prix_total: { type: Number, required: false},
});

const Fil = mongoose.model("Fil", FilSchema);
module.exports = Fil;
