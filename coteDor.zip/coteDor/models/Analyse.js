const mongoose = require("mongoose");

const AnalyseSchema = new mongoose.Schema({
	name_machine: { type: String, required: false },
	heure_debut: {
		type:String
	},
	heure_fin: {
		type:String
	},
	produit_initial: { type: String, required: false },
	fils_produit: { type: String, required: false },
	dechet: { type: String, required: false },
	seuils: { type: String, required: false },
	consommation_energie: { type: Number, required: false },
	rendement: { type: Number, required: false },
	consommation_specifique: { type: Number, required: false },
	etat: {
        type: String,
        enum: ["normale", "panne", "maintenance", "changement operateur"],
        default: "normale",
    },
});

const Analyse = mongoose.model("Analyse", AnalyseSchema);
module.exports = Analyse;
