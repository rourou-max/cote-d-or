const mongoose = require('mongoose');

const analysefinanciereSchema = new mongoose.Schema({
    annee: {
        type: Number,
        required: true
    },
    mois: {
        type: String,
        required: true
    },
    ventes: {
        type: Number,
        required: true,
        default: 0
    },
    achats: {
        type: Number,
        required: true,
        default: 0
    },
    marge: {
        type: Number,
        required: true,
        default: 0
    },
    rentabilite: {
        type: Number,
        required: true,
        default: 0
    }
}, { timestamps: true });

module.exports = mongoose.model('analysefinanciere', analysefinanciereSchema);