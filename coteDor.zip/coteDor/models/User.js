const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    email: { type: String, required: true },
    nom: { type: String, required: true },
    password: { type: String, required: true },
    prenom: { type: String, required: true },
    telephone: { type: String, required: true },
    isActive: {
        type: Boolean,
        default: true,
    },
    role: {
        type: String,
        enum: ["admin", "client"],
        default: "client",
        required: true
    }
});

const User = mongoose.model("User", UserSchema);
module.exports = User;