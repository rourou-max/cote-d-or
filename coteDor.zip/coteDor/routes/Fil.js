const express = require('express');
const router = express.Router();
const filController = require('../controller/filController');
const authMiddleware = require('../middlewares/authMiddleware');
const path = require('path');

router.get('/add', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'fil_add.html'));
});

router.post('/add', filController.addFil);

router.get('/update/:id', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'fil_update.html'));
});

router.put('/update/:id', filController.UpdateFil);

router.get('/list', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'fil_list.html'));
});

router.get('/list_fil', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'fil_list_admin.html'));
});
router.get('/getall', filController.GetAllFil);

router.get('/user', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'fil_user.html'));
});

router.get('/getbyuser', authMiddleware, filController.GetFilByUser);
router.get('/getbyuser/:userId', filController.GetFilByUser);

router.get('/getbyid/:id', filController.GetFilById);

module.exports = router;