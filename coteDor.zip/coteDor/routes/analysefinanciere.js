const express = require('express');
const router = express.Router();
const analysefinanciere = require('../models/analysefinanciere');

router.post('/enregistrer', async (req, res) => {
    try {
        const { annee, mois, ventes, achats, marge, rentabilite } = req.body;

        if (!annee || !mois || !ventes || !achats || !marge || !rentabilite) {
            return res.status(400).json({ error: 'Tous les champs sont requis' });
        }

        const analysefinanciereData = mois.map((m, index) => ({
            annee: parseInt(annee),
            mois: m,
            ventes: parseFloat(ventes[index] || 0),
            achats: parseFloat(achats[index] || 0),
            marge: parseFloat(marge[index] || 0),
            rentabilite: parseFloat(rentabilite[index] || 0)
        }));

        await Analyse.insertMany(analysefinanciereData);

        res.status(201).json({ message: 'Données enregistrées avec succès' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erreur lors de l\'enregistrement' });
    }
});

module.exports = router;
