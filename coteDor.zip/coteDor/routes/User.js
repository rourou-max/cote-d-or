const express = require('express');
const router = express.Router();
const userController = require('../controller/userController');
const authMiddleware = require("../middlewares/authMiddleware");
const path = require('path');

router.post('/adduser', userController.addUser);
router.post('/login', userController.login);
router.put('/update_user/:id', authMiddleware, userController.updateUser);
router.get('/getalluser', userController.getAllUser);
router.get('/getuser/:userId', authMiddleware, userController.getByIdUser);
router.get('/refresh_token', userController.refreshToken);
router.get('/logout', userController.logout);
router.get('/info', authMiddleware, userController.getUserByToken);

// Route pour afficher la liste des utilisateurs (HTML statique)
router.get('/list', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'user_list.html'));
});

module.exports = router;