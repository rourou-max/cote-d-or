const express = require('express');
const router = express.Router();
const commandeController = require('../controller/commandeController');
const path = require('path');
const authMiddleware = require("../middlewares/authMiddleware");

// Route pour afficher le formulaire HTML
router.get('/add', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'commande.html'));
});

// Route pour traiter la soumission du formulaire
router.post('/add', commandeController.AddCommande);

// Route pour afficher la liste des commandes
router.get('/list', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'commande_list.html'));
});
// Route pour afficher la liste des commandes
router.get('/list_commande', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'commande_list_admin.html'));
});
// Route pour récupérer les commandes d'un utilisateur
router.get('/getByUser/:userId', authMiddleware, commandeController.getCommandesByUser);

// Route pour récupérer les commandes de l'utilisateur connecté
router.get('/getByUser', authMiddleware, commandeController.getCommandesByCurrentUser);

router.get('/getallcommande', commandeController.getAllCommandes);

router.put('/updateStatus/:id', commandeController.updateCommandeStatus);

module.exports = router;