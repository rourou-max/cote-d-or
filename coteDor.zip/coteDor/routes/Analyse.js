const express = require('express');
const router = express.Router();
const analyseController = require('../controller/analyseContoller');
const path = require('path');

// Route pour afficher le formulaire HTML
router.get('/add', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'analyse.html'));
});

router.post('/add', analyseController.addAnalyse);

router.get('/list', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'list_analyse.html'));
});

router.get('/getall', analyseController.getAllAnalyses);
module.exports = router;