const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    // Vérifier l'en-tête Authorization
    const authHeader = req.headers['authorization'] || req.headers['Authorization'];

    if (!authHeader) {
        console.error('No Authorization header provided');
        return res.status(401).json({ message: 'Aucun en-tête Authorization fourni' });
    }

    // Vérifier que l'en-tête commence par "Bearer "
    if (!authHeader.startsWith('Bearer ')) {
        console.error('Invalid Authorization header format');
        return res.status(401).json({ message: 'Format d\'en-tête Authorization invalide' });
    }

    // Extraire le token
    const token = authHeader.split(' ')[1];
    if (!token) {
        console.error('No token provided in Authorization header');
        return res.status(401).json({ message: 'Aucun token fourni' });
    }

    try {
        const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
        req.user = decoded; // Stocke les informations décodées (contient `id`)
        next();
    } catch (error) {
        console.error('Token verification error:', error.message);
        return res.status(401).json({ message: 'Token invalide ou expiré' });
    }
};

module.exports = authMiddleware;